# Generated with MC-Build

$data modify storage minecraft:ui generate.death_message.lore append from storage minecraft:ability index.$(ability_id).moveset.slot$(move).move$(variation).description[20][]
data modify storage minecraft:ui generate.death_message.lore append value "\n"