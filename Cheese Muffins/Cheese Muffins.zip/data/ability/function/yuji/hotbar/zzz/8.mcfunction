# Generated with MC-Build

function custom:universal/hotbar/time {ability:"yuji",selected:3}