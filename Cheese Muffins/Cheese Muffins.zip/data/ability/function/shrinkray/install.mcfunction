# Generated with MC-Build

scoreboard objectives add abilityShrinkray.PassiveAmmoValue dummy
scoreboard objectives add abilityShrinkray.PassiveAmmoReload dummy
scoreboard objectives add abilityShrinkray.Beam dummy
scoreboard objectives add abilityShrinkray.BeamID dummy
scoreboard objectives add abilityShrinkray.BeamMode dummy
function universal:ability/setup/cooldown/10x {name:"Shrinkray_Shoot",storage:"shrinkray",path:"1a",move:1,cooldown:1}
function universal:ability/setup/cooldown/10x {name:"Shrinkray_Self",storage:"shrinkray",path:"1b",move:1,cooldown:3}
function universal:ability/setup/cooldown/10x {name:"Shrinkray_Shoot",storage:"shrinkray",path:"2a",move:2,cooldown:1}
function universal:ability/setup/cooldown/10x {name:"Shrinkray_Self",storage:"shrinkray",path:"2b",move:2,cooldown:3}