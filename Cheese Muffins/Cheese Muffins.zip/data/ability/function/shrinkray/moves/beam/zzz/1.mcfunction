# Generated with MC-Build

function ability:shrinkray/moves/setup {rig:"shrinkray",animation:'shoot_gabi'}
function universal:ability/play/sfx {sfx:"minecraft:entity.breeze.inhale",selector:"@a",volume:0.5,objective:"universalAbility.ID"}