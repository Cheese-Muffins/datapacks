# Generated with MC-Build

scoreboard players reset @s universalAbility.MoveTrigger3
execute if score @s universalAbility.ToggleState matches 1 unless score @s universalAbility.ToggleDelay matches 1.. unless score @s universalAbility.MoveDelay matches 1.. run function ability:billy/moves/3/core